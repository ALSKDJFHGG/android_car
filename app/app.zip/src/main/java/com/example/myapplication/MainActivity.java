package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    List<news_item> news_items;
    ListView lv_news;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        news_items=new ArrayList<>();
        lv_news=findViewById(R.id.lv_news);
    }

    Handler mHander =new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            myadapter mda=new myadapter();
            lv_news.setAdapter(mda);

        }
    };



    public void load_okhttp(View view){

        String apiKey = "43b68b4789b8159caae6c69dc47beaa9";
        String apiUrl = "http://v.juhe.cn/toutiao/index";

        HashMap<String, String> map = new HashMap<>();
        map.put("key", apiKey);
        map.put("type", "");
        map.put("page", "");
        map.put("page_size", "");
        map.put("is_filter", "");

        try {
            URL url = new URL(String.format("%s?%s", apiUrl, params(map)));

            OkHttpClient okHttpClient = new OkHttpClient();

            Request request = new Request.Builder().url(url).build();

            Call call = okHttpClient.newCall(request);

            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {

                    Log.i("结果", "onFailure: "+"网络请求失败！");
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    String content = response.body().string();

                    try {
                        JSONObject jsonObject = new JSONObject(content);
                        JSONObject result = jsonObject.optJSONObject("result");
                        JSONArray data = result.optJSONArray("data");
                        Gson gson = new Gson();
                        Type type = new TypeToken<List<news_item>>() {
                        }.getType();
                        news_items = gson.fromJson(data.toString(), type);

                        Message message = new Message();

                        mHander.sendMessage(message);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }


            });

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

    }

    public void get_req(View view) {

        OkHttpClient okHttpClient = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://www.baidu.com")
                .build();

        Call call = okHttpClient.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.i("结果", "onFailure: "+"网络连接失败！");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.i("结果", "onResponse: "+response.body().string());
            }
        });
    }
    public static String params(Map<String, String> map) {
        return map.entrySet().stream()
                .map(entry -> {
                    try {
                        return entry.getKey() + "=" + URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                        return entry.getKey() + "=" + entry.getValue();
                    }
                })
                .collect(Collectors.joining("&"));
    }

    class myadapter extends BaseAdapter{

        @Override
        public int getCount() {
            return news_items.size();
        }

        @Override
        public Object getItem(int position) {
            return news_items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View inflate = View.inflate(MainActivity.this, R.layout.news_item, null);
            TextView title = inflate.findViewById(R.id.title);
            TextView date = inflate.findViewById(R.id.date);
            TextView author_name = inflate.findViewById(R.id.author_name);
            news_item item = news_items.get(position);
            title.setText(item.getTitle());
            date.setText(item.getDate());
            author_name.setText(item.getAuther_name());
            return inflate;
        }
    }


}
